import { hashSeed, createNoise } from './noise.js';
import { generatePlates, assignPlates, computeBoundaries } from './tectonic.js';
import { generateElevation, hydraulicErosion, generateLakes } from './erosion.js';
import { generateRivers } from './rivers.js';
import { analyzeRegions, computeClimate } from './regions.js';

const ASPECT_MAP = { '1:1': 1, '4:3': 4/3, '16:9': 16/9, '2:1': 2, '3:2': 3/2 };

export function generateMap(params, onProgress) {
  const seed = hashSeed(params.seedStr);
  const aspect = ASPECT_MAP[params.mapAspect] || 1;
  const width = params.mapSize;
  const height = Math.round(params.mapSize / aspect);

  const phases = [
    { name: 'tectonic', weight: 10 },
    { name: 'elevation', weight: 30 },
    { name: 'erosion', weight: 25 },
    { name: 'climate', weight: 10 },
    { name: 'lakes', weight: 5 },
    { name: 'rivers', weight: 10 },
    { name: 'regions', weight: 5 },
    { name: 'packing', weight: 5 },
  ];
  const totalWeight = phases.reduce((s, p) => s + p.weight, 0);
  let progress = 0;

  function advance(phaseName) {
    const p = phases.find(x => x.name === phaseName);
    if (p) progress += p.weight / totalWeight;
    if (onProgress) onProgress(progress, phaseName);
  }

  advance('tectonic');
  const plates = generatePlates(seed, params.plateCount, width, height, params.landmass);
  const { plateId, plateDist } = assignPlates(width, height, plates);
  const boundary = computeBoundaries(width, height, plateId);
  const checkpointTectonic = { plates, plateId: new Float32Array(plateId), plateDist: new Float32Array(plateDist), boundary: new Float32Array(boundary) };

  advance('elevation');
  let { elevation, slope, ridge, ridgeMask } = generateElevation(
    width, height, seed, plateId, plates, boundary,
    params.noiseType, params.fbmType, params.octaves,
    params.lacunarity, params.persistence, params.seaLevel,
    params.mountainFold, params.coastDetail
  );
  const checkpointElevation = { elevation: new Float32Array(elevation), slope: new Float32Array(slope), ridge: new Float32Array(ridge), ridgeMask: new Float32Array(ridgeMask) };

  advance('erosion');
  if (params.erosionIterations > 0 && params.erosionStrength > 0) {
    elevation = hydraulicErosion(width, height, elevation, params.erosionIterations, params.erosionStrength);
  }
  const checkpointErosion = { elevation: new Float32Array(elevation) };

  advance('climate');
  const { temperature, tempZone, moisture, rainfall } = computeClimate(
    width, height, elevation, params.seaLevel, params.tempOffset, params.snowLine
  );
  const checkpointClimate = { temperature: new Float32Array(temperature), tempZone: new Float32Array(tempZone), moisture: new Float32Array(moisture), rainfall: new Float32Array(rainfall) };

  advance('lakes');
  const lakes = generateLakes(width, height, elevation, params.seaLevel, params.lakeDensity, seed);

  advance('rivers');
  const riverCount = Math.floor(width * height * 0.0005);
  const { rivers, riverMask, riverWidth, riverDepth } = generateRivers(
    width, height, elevation, moisture, params.seaLevel, riverCount, seed
  );
  const checkpointRivers = { rivers, riverMask: new Float32Array(riverMask), riverWidth: new Float32Array(riverWidth), riverDepth: new Float32Array(riverDepth), lakes: new Float32Array(lakes) };

  advance('regions');
  const regions = analyzeRegions(width, height, elevation, moisture, temperature, plateId, params.seaLevel, seed);

advance('packing');
const size = width * height;

let elevMin = Infinity, elevMax = -Infinity;
for (let i = 0; i < size; i++) {
  if (elevation[i] < elevMin) elevMin = elevation[i];
  if (elevation[i] > elevMax) elevMax = elevation[i];
}
const elevRange = elevMax - elevMin || 1;
for (let i = 0; i < size; i++) {
  elevation[i] = (elevation[i] - elevMin) / elevRange;
}
  const plateTex = new Float32Array(size * 4);
  const elevTex = new Float32Array(size * 4);
  const moistTex = new Float32Array(size * 4);
  const riverTex = new Float32Array(size * 4);
  const tempTex = new Float32Array(size * 4);

  const plateTypeArr = new Uint8Array(plates.length);
  for (let i = 0; i < plates.length; i++) {
    plateTypeArr[i] = plates[i].type === 'continent' ? 1 : 0;
  }

  for (let i = 0; i < size; i++) {
    const pid = Math.floor(plateId[i]);
    const i4 = i * 4;
    plateTex[i4 + 0] = pid / params.plateCount;
    plateTex[i4 + 1] = plateTypeArr[pid];
    plateTex[i4 + 2] = boundary[i];
    plateTex[i4 + 3] = plateDist[i];
    elevTex[i4 + 0] = elevation[i];
    elevTex[i4 + 1] = slope[i];
    elevTex[i4 + 2] = ridge[i];
    elevTex[i4 + 3] = ridgeMask[i];
    moistTex[i4 + 0] = moisture[i];
    moistTex[i4 + 1] = rainfall[i];
    moistTex[i4 + 2] = temperature[i];
    moistTex[i4 + 3] = tempZone[i] / 4;
    riverTex[i4 + 0] = riverMask[i];
    riverTex[i4 + 1] = riverWidth[i];
    riverTex[i4 + 2] = riverDepth[i];
    riverTex[i4 + 3] = lakes[i];

    const elev = elevation[i];
    const temp = temperature[i];
    const moist = moisture[i];
    let biome = 0;
    if (elev <= params.seaLevel) biome = 0;
    else if (temp < params.snowLine && elev > 0.6) biome = 1;
    else if (elev > 0.7) biome = 2;
    else if (moist < 0.2 && temp > 0.5) biome = 3;
    else if (moist > 0.7 && temp > 0.4) biome = 4;
    else if (moist > 0.5 && temp > 0.3) biome = 5;
    else if (temp < 0.2) biome = 6;
    else biome = 7;
    tempTex[i4 + 0] = temperature[i];
    tempTex[i4 + 1] = tempZone[i] / 4;
    tempTex[i4 + 2] = biome / 8;
    tempTex[i4 + 3] = 0;
  }

  const mapData = {
    width, height,
    plateTex, elevTex, moistTex, riverTex, tempTex,
    plates, regions, rivers, seed,
  };

  return {
    mapData,
    checkpoints: {
      tectonic: checkpointTectonic,
      elevation: checkpointElevation,
      erosion: checkpointErosion,
      climate: checkpointClimate,
      rivers: checkpointRivers,
    },
  };
}

export function restoreFromCheckpoint(checkpoint, params) {
  const { elevation, moisture, temperature, tempZone, rainfall, plates, plateId, boundary, plateDist } = checkpoint;
  const width = params.mapSize;
  const aspect = ASPECT_MAP[params.mapAspect] || 1;
  const height = Math.round(params.mapSize / aspect);
  const size = width * height;

  const plateTex = new Float32Array(size * 4);
  const elevTex = new Float32Array(size * 4);
  const moistTex = new Float32Array(size * 4);
  const riverTex = new Float32Array(size * 4);
  const tempTex = new Float32Array(size * 4);

  const plateTypeArr = new Uint8Array(plates.length);
  for (let i = 0; i < plates.length; i++) {
    plateTypeArr[i] = plates[i].type === 'continent' ? 1 : 0;
  }

  for (let i = 0; i < size; i++) {
    const pid = Math.floor(plateId[i]);
    const i4 = i * 4;
    plateTex[i4 + 0] = pid / params.plateCount;
    plateTex[i4 + 1] = plateTypeArr[pid];
    plateTex[i4 + 2] = boundary[i];
    plateTex[i4 + 3] = plateDist[i];
    elevTex[i4] = elevation[i];
    const elev = elevation[i];
    const temp = temperature ? temperature[i] : 0;
    const moist = moisture ? moisture[i] : 0.5;
    let biome = 0;
    if (elev <= params.seaLevel) biome = 0;
    else if (elev > 0.7) biome = 2;
    else if (moist < 0.2 && temp > 0.5) biome = 3;
    else if (moist > 0.5 && temp > 0.3) biome = 5;
    else if (temp < 0.2) biome = 6;
    else biome = 7;
    moistTex[i4] = moist;
    moistTex[i4 + 2] = temp;
    tempTex[i4] = temp;
    tempTex[i4 + 2] = biome / 8;
  }

  return {
    width, height, plateTex, elevTex, moistTex, riverTex, tempTex,
    plates, regions: [], rivers: [], seed: 0,
  };
}
