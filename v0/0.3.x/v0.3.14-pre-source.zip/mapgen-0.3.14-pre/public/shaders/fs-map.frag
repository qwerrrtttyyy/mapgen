#version 300 es
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D u_plateTex;
uniform sampler2D u_elevTex;
uniform sampler2D u_moistureTex;
uniform sampler2D u_tempTex;
uniform sampler2D u_riverTex;
uniform sampler2D u_selectionMaskTex;
uniform sampler2D u_trailTex;
uniform int u_style;
uniform float u_seaLevel;
uniform float u_lightAngle;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_showBoundaries;
uniform float u_boundaryWidth;
uniform vec3 u_boundaryColor;
uniform float u_pointLightEnabled;
uniform vec2 u_pointLightPos;
uniform float u_pointLightIntensity;
uniform vec3 u_pointLightColor;
uniform float u_glowEnabled;
uniform vec2 u_laserStart;
uniform vec2 u_laserEnd;
uniform float u_laserActive;
uniform float u_laserWidth;
uniform float u_hasTrail;
uniform int u_selectedCount;
uniform int u_plateTotal;
uniform int u_fbmOctaves;
uniform float u_fbmLacunarity;
uniform float u_fbmPersistence;
uniform float u_snowLine;
uniform float u_erosionStrength;
uniform float u_showRivers;
uniform float u_contourInterval;
uniform float u_showContours;
uniform float u_showTerrain;    /* v0.3.1: 图层开关——地形底图 */
uniform float u_showSelection;  /* v0.3.1: 图层开关——选中高亮 */
uniform float u_showClimate;    /* v0.3.2: 气候分区可视化 */
uniform vec2 u_cursorPos;       /* v0.3.4: 光标位置 (UV空间) */
uniform float u_cursorActive;   /* v0.3.4: 光标启用 */
uniform float u_cursorSize;     /* v0.3.4: 光标半径 (像素) */
/* v0.3.6: 细节生成器 uniforms */
uniform float u_detailRiverWidth;     /* 河流宽度缩放 */
uniform float u_detailRiverCurve;     /* 河流曲率 */
uniform float u_detailCoastJagged;    /* 海岸线锯齿度 */
uniform float u_detailRidgeDensity;   /* 山脊密度 */
uniform float u_detailRainfallOffset; /* 降雨带偏移 */
uniform float u_detailTempGradient;   /* 温度梯度 */
uniform float u_detailBiomeBlend;     /* 群系混合度 */
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
float fbmNoise(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 8; i++) {
        if (i >= u_fbmOctaves) break;
        v += a * vnoise(p);
        p *= 2.03;
        a *= 0.5;
    }
    return v;
}
/* v0.3.0: 平滑渐变地形着色——含微噪声扰动 */
vec3 terrainColor(float h, float sea, float moisture) {
    vec3 col;
    // 深海: 靛蓝→钴蓝
    if (h < sea - 0.3) {
        float t = clamp((h - (sea - 0.6)) / 0.3, 0.0, 1.0);
        col = mix(vec3(0.02, 0.06, 0.22), vec3(0.06, 0.18, 0.55), t);
    }
    // 浅海: 钴蓝→青绿
    else if (h < sea - 0.05) {
        float t = clamp((h - (sea - 0.3)) / 0.25, 0.0, 1.0);
        col = mix(vec3(0.06, 0.18, 0.55), vec3(0.10, 0.45, 0.70), t);
    }
    // 近岸: 青绿→沙滩
    else if (h < sea) {
        float t = clamp((h - (sea - 0.05)) / 0.05, 0.0, 1.0);
        col = mix(vec3(0.10, 0.45, 0.70), vec3(0.90, 0.82, 0.58), t);
    }
    // 沙滩
    else if (h < sea + 0.012) {
        col = vec3(0.90, 0.82, 0.58);
    }
    // 草地→森林 (受湿度影响)
    else if (h < sea + 0.15) {
        float t = clamp((h - sea - 0.012) / 0.138, 0.0, 1.0);
        vec3 grass = mix(vec3(0.28, 0.65, 0.18), vec3(0.18, 0.48, 0.12), moisture);
        col = mix(vec3(0.90, 0.82, 0.58), grass, t);
    }
    // 丘陵
    else if (h < sea + 0.30) {
        float t = clamp((h - sea - 0.15) / 0.15, 0.0, 1.0);
        col = mix(vec3(0.18, 0.48, 0.12), vec3(0.45, 0.35, 0.18), t);
    }
    // 山地
    else if (h < sea + 0.55) {
        float t = clamp((h - sea - 0.30) / 0.25, 0.0, 1.0);
        col = mix(vec3(0.45, 0.35, 0.18), vec3(0.55, 0.50, 0.48), t);
    }
    // 雪山
    else {
        float t = clamp((h - sea - 0.55) / 0.45, 0.0, 1.0);
        col = mix(vec3(0.55, 0.50, 0.48), vec3(0.95, 0.95, 0.98), t);
    }
    // 微噪声扰动
    float microVar = (vnoise(v_uv * 200.0) - 0.5) * 0.04;
    col = col * (1.0 + microVar);
    return col;
}
vec3 platesColor(float plateId, float elev, float sea, float shade) {
    float hue = fract(plateId * 0.618033988749895 + 0.05);
    vec3 col = elev < sea ? hsv2rgb(vec3(hue, 0.55, 0.75)) : hsv2rgb(vec3(hue, 0.50, 0.95));
    return col * mix(0.75, 1.05, shade);
}
vec3 parchmentColor(float h, float sea, float boundary, float plateType) {
    vec3 paper = mix(vec3(.88, .78, .58), vec3(.82, .72, .52), fbmNoise(v_uv * 8.0));
    paper = mix(paper, paper * 0.75, smoothstep(0.62, 0.68, fbmNoise(v_uv * 12.0 + 50.0)) * 0.4);
    float edgeDist = min(min(v_uv.x, 1.0 - v_uv.x), min(v_uv.y, 1.0 - v_uv.y));
    paper = mix(paper, vec3(.3, .18, .08), smoothstep(0.08, 0.0, edgeDist) * 0.8);
    vec3 ink;
    if (h < sea) ink = mix(vec3(.45, .55, .65), vec3(.25, .35, .50), sea > 0.001 ? (sea - h) / sea : 0.0);
    else ink = mix(vec3(.6, .55, .35), vec3(.45, .35, .2), (h - sea) / (1.0 - sea + 0.001));
    vec3 col = mix(paper, ink, 0.72);
    if (u_showBoundaries > 0.5 && boundary > u_boundaryWidth * 0.1) col = mix(col, vec3(.45, .15, .08), boundary * 0.85);
    col *= mix(0.6, 1.0, smoothstep(0.0, 0.7, 1.0 - length((v_uv - 0.5) * 1.3))); return col;
}
/* v0.3.0: 增强 hillshade——4px Sobel 算子 */
float hillshade(vec2 uv, float lightAng) {
    vec2 tx = 1.0 / u_resolution;
    // 4px 范围 Sobel 算子
    float hTL = texture(u_elevTex, uv + vec2(-tx.x,  tx.y)).r;
    float hTC = texture(u_elevTex, uv + vec2( 0.0,   tx.y)).r;
    float hTR = texture(u_elevTex, uv + vec2( tx.x,  tx.y)).r;
    float hML = texture(u_elevTex, uv + vec2(-tx.x,  0.0)).r;
    float hMR = texture(u_elevTex, uv + vec2( tx.x,  0.0)).r;
    float hBL = texture(u_elevTex, uv + vec2(-tx.x, -tx.y)).r;
    float hBC = texture(u_elevTex, uv + vec2( 0.0,  -tx.y)).r;
    float hBR = texture(u_elevTex, uv + vec2( tx.x, -tx.y)).r;
    float dhdx = (hTR + 2.0 * hMR + hBR) - (hTL + 2.0 * hML + hBL);
    float dhdy = (hBL + 2.0 * hBC + hBR) - (hTL + 2.0 * hTC + hTR);
    vec3 normal = normalize(vec3(dhdx, dhdy, 0.06));
    vec3 lightDir = normalize(vec3(cos(lightAng), sin(lightAng), 0.6));
    return clamp(dot(normal, lightDir), 0.15, 1.0);
}
/* v0.3.0: 地形详情着色 (风格5) */
vec3 terrainDetailColor(float h, float sea, float moisture, float river, float shade) {
    vec3 col = terrainColor(h, sea, moisture);
    // 河流叠加
    if (u_showRivers > 0.5 && river > 0.0 && h >= sea) {
        vec3 riverCol = mix(vec3(0.15, 0.35, 0.55), vec3(0.20, 0.50, 0.70), river);
        col = mix(col, riverCol, river * 0.7);
    }
    // 湿度植被效果
    if (h >= sea) {
        float veg = moisture * (1.0 - smoothstep(sea + 0.3, sea + 0.55, h));
        col = mix(col, col * vec3(0.85, 1.1, 0.8), veg * 0.3);
    }
    col *= shade;
    return col;
}
/* v0.3.0: 生物群落着色 (风格6) */
vec3 biomeColor(float temp, float moist, float h, float sea, float shade) {
    // 水域
    if (h < sea) {
        float t = clamp((h - (sea - 0.3)) / 0.3, 0.0, 1.0);
        return mix(vec3(0.02, 0.06, 0.22), vec3(0.10, 0.45, 0.70), t) * shade;
    }
    vec3 col;
    float ht = (h - sea) / (1.0 - sea + 0.001);
    // 热带雨林 (热+湿)
    if (temp > 0.7 && moist > 0.55) {
        col = mix(vec3(0.08, 0.35, 0.06), vec3(0.05, 0.25, 0.04), ht);
    }
    // 热带草原 (热+干)
    else if (temp > 0.7 && moist <= 0.55) {
        col = mix(vec3(0.65, 0.62, 0.28), vec3(0.55, 0.50, 0.22), ht);
    }
    // 沙漠 (热+极干)
    else if (temp > 0.6 && moist < 0.2) {
        col = mix(vec3(0.85, 0.78, 0.52), vec3(0.75, 0.65, 0.40), ht);
    }
    // 温带森林 (温+湿)
    else if (temp > 0.35 && moist > 0.5) {
        col = mix(vec3(0.15, 0.50, 0.10), vec3(0.10, 0.38, 0.08), ht);
    }
    // 温带草原 (温+干)
    else if (temp > 0.35 && moist <= 0.5) {
        col = mix(vec3(0.50, 0.60, 0.25), vec3(0.42, 0.50, 0.20), ht);
    }
    // 寒带苔原 (冷)
    else if (temp > 0.15) {
        col = mix(vec3(0.45, 0.52, 0.38), vec3(0.55, 0.55, 0.50), ht);
    }
    // 极地冰盖 (极冷)
    else {
        col = mix(vec3(0.82, 0.88, 0.90), vec3(0.95, 0.97, 1.0), ht);
    }
    // 高海拔雪线
    float snowH = u_snowLine;
    if (ht > snowH) {
        float snowT = clamp((ht - snowH) / 0.15, 0.0, 1.0);
        col = mix(col, vec3(0.95, 0.95, 0.98), snowT);
    }
    float microVar = (vnoise(v_uv * 150.0) - 0.5) * 0.03;
    col = col * (1.0 + microVar);
    // 气候分区边界线 (v0.3.6: 细节生成器降雨/温度偏移)
    if (u_showClimate > 0.5 && h >= sea) {
        float tempGrad = length(vec2(dFdx(temp), dFdy(temp))) * u_detailTempGradient;
        float moistGrad = length(vec2(dFdx(moist), dFdy(moist)));
        float boundary = smoothstep(0.01, 0.04, tempGrad + moistGrad);
        col = mix(col, vec3(1.0, 0.95, 0.4), boundary * 0.5);
    }
    return col * shade;
}
/* v0.3.0: 等高线着色 (风格7) */
vec3 contourColor(float h, float sea, float shade) {
    if (u_showContours < 0.5) return terrainColor(h, sea, 0.5) * shade;
    vec3 col = terrainColor(h, sea, 0.5);
    // 等高线计算
    float interval = u_contourInterval * 0.01;
    float contourFrac = fract(h / interval);
    float contourLine = 1.0 - smoothstep(0.02, 0.05, contourFrac) * smoothstep(0.0, 0.02, contourFrac);
    // 主等高线 (每5条加粗)
    float majorFrac = fract(h / (interval * 5.0));
    float majorLine = 1.0 - smoothstep(0.015, 0.04, majorFrac) * smoothstep(0.0, 0.015, majorFrac);
    // 半透明填充
    float fill = floor(h / interval) * interval;
    vec3 fillColor = terrainColor(fill + interval * 0.5, sea, 0.5);
    col = mix(col, fillColor, 0.15);
    // 绘制线条
    if (h >= sea) {
        col = mix(col, vec3(0.25, 0.20, 0.15), contourLine * 0.5);
        col = mix(col, vec3(0.15, 0.12, 0.08), majorLine * 0.7);
    }
    col *= shade;
    return col;
}
/* v0.3.0: 山体浮雕着色 (风格8) */
vec3 reliefColor(float h, float sea, float shade) {
    vec3 col = terrainColor(h, sea, 0.5);
    // 增强光照
    float enhanced = pow(shade, 0.7);
    // 添加环境光遮蔽
    vec2 tx = 1.0 / u_resolution;
    float hC = texture(u_elevTex, v_uv).r;
    float ao = 0.0;
    for (int dy = -2; dy <= 2; dy++) {
        for (int dx = -2; dx <= 2; dx++) {
            if (dx == 0 && dy == 0) continue;
            float hN = texture(u_elevTex, v_uv + vec2(float(dx), float(dy)) * tx * 2.0).r;
            if (hN > hC) ao += (hN - hC) * 0.3;
        }
    }
    ao = clamp(1.0 - ao, 0.5, 1.0);
    col *= enhanced * ao;
    // 色调映射增加对比
    col = pow(col, vec3(0.9));
    return col;
}
/* v0.3.4: Azgaar 风格着色 (风格9) —— 近似 Azgaar 地图生成器的暖色手绘风格 */
vec3 azgaarColor(float h, float sea, float moisture, float temp, float river, float shade, float boundary) {
    vec3 col;
    // 海洋: 深靛蓝到浅蓝灰——Azgaar特有的柔和海蓝色调
    if (h < sea - 0.15) {
        float t = clamp((h - (sea - 0.6)) / 0.45, 0.0, 1.0);
        col = mix(vec3(0.08, 0.14, 0.30), vec3(0.22, 0.38, 0.55), t);
    }
    // 浅海: 柔和的蓝色过渡
    else if (h < sea) {
        float t = clamp((h - (sea - 0.15)) / 0.15, 0.0, 1.0);
        col = mix(vec3(0.22, 0.38, 0.55), vec3(0.52, 0.62, 0.70), t);
    }
    // 海岸线: 明显的暗线强调 (Azgaar 标志性特征)
    else if (h < sea + 0.018 + u_detailCoastJagged * 0.008) {
        float jagged = vnoise(v_uv * 120.0) * u_detailCoastJagged * 0.015;
        col = vec3(0.38 + jagged, 0.36 + jagged * 0.5, 0.28 - jagged * 0.3);
    }
    // 沙滩: 暖米色
    else if (h < sea + 0.035) {
        float t = clamp((h - sea - 0.018) / 0.017, 0.0, 1.0);
        col = mix(vec3(0.38, 0.36, 0.28), vec3(0.82, 0.75, 0.55), t);
    }
    // 低地: 橄榄绿到温暖草地
    else if (h < sea + 0.12) {
        float t = clamp((h - sea - 0.035) / 0.085, 0.0, 1.0);
        vec3 lowWet = vec3(0.42, 0.56, 0.25);  // 湿润低地——鲜绿
        vec3 lowDry = vec3(0.62, 0.60, 0.30);   // 干燥低地——黄绿
        vec3 low = mix(lowDry, lowWet, clamp(moisture * 1.4, 0.0, 1.0));
        col = mix(vec3(0.82, 0.75, 0.55), low, t);
    }
    // 丘陵: 暖棕色到橄榄色
    else if (h < sea + 0.25) {
        float t = clamp((h - sea - 0.12) / 0.13, 0.0, 1.0);
        vec3 hillWet = vec3(0.35, 0.46, 0.18);
        vec3 hillDry = vec3(0.58, 0.48, 0.28);
        vec3 hill = mix(hillDry, hillWet, clamp(moisture, 0.0, 1.0));
        col = mix(hill, vec3(0.48, 0.38, 0.24), t);
    }
    // 山地: 灰棕色 (v0.3.6: 细节生成器山脊密度)
    else if (h < sea + 0.45) {
        float t = clamp((h - sea - 0.25) / 0.20, 0.0, 1.0);
        float ridgeNoise = vnoise(v_uv * 80.0) * u_detailRidgeDensity * 0.08;
        col = mix(vec3(0.48 + ridgeNoise, 0.38 + ridgeNoise * 0.6, 0.24 - ridgeNoise * 0.2), vec3(0.58, 0.54, 0.48), t);
    }
    // 高山: 浅灰
    else if (h < sea + 0.60) {
        float t = clamp((h - sea - 0.45) / 0.15, 0.0, 1.0);
        float ridgeNoise = vnoise(v_uv * 80.0) * u_detailRidgeDensity * 0.06;
        col = mix(vec3(0.58 + ridgeNoise, 0.54 + ridgeNoise * 0.5, 0.48 - ridgeNoise * 0.3), vec3(0.75, 0.73, 0.70), t);
    }
    // 雪线: 柔和白
    else {
        float t = clamp((h - sea - 0.60) / 0.40, 0.0, 1.0);
        col = mix(vec3(0.75, 0.73, 0.70), vec3(0.93, 0.93, 0.95), t);
    }
    // 河流叠加——Azgaar风格的蓝色河流线
    if (u_showRivers > 0.5 && river > 0.0 && h >= sea) {
        float rw = u_detailRiverWidth; // v0.3.6: 细节生成器河流宽度
        float riverAlpha = river * (0.35 + rw * 0.30);
        vec3 riverCol = mix(vec3(0.30, 0.42, 0.58), vec3(0.40, 0.55, 0.72), river);
        col = mix(col, riverCol, clamp(riverAlpha, 0.0, 1.0));
    }
    // 微噪声纹理——模拟手绘质感
    float microVar = (vnoise(v_uv * 180.0) - 0.5) * 0.035;
    col = col * (1.0 + microVar);
    // 纸张暖色滤镜——整体暖色偏移
    col = mix(col, col * vec3(1.04, 1.01, 0.96), 0.3);
    // hillshade光照
    col *= shade;
    // 海岸线暗线强调 (Azgaar标志性特征: 陆地边缘的深色描边)
    if (h >= sea && h < sea + 0.06) {
        vec2 tx2 = 1.0 / u_resolution;
        float hL = texture(u_elevTex, v_uv + vec2(-tx2.x, 0.0)).r;
        float hR = texture(u_elevTex, v_uv + vec2( tx2.x, 0.0)).r;
        float hU = texture(u_elevTex, v_uv + vec2(0.0,  tx2.y)).r;
        float hD = texture(u_elevTex, v_uv + vec2(0.0, -tx2.y)).r;
        bool nearSea = (hL < sea || hR < sea || hU < sea || hD < sea);
        if (nearSea) {
            col = mix(col, vec3(0.22, 0.20, 0.16), 0.65);
        }
    }
    // 板块边界虚线效果 (Azgaar风格的红色边界)
    if (u_showBoundaries > 0.5 && boundary > 0.1) {
        float dashPattern = step(0.5, fract(v_uv.x * 80.0 + v_uv.y * 60.0));
        col = mix(col, vec3(0.55, 0.18, 0.12), boundary * 0.7 * dashPattern);
    }
    // 柔和暗角效果
    float vignette = smoothstep(0.0, 0.4, min(min(v_uv.x, 1.0 - v_uv.x), min(v_uv.y, 1.0 - v_uv.y)));
    col *= mix(0.82, 1.0, vignette);
    return col;
}
float distToSegment(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h);
}
bool isSelected(float plateIdNorm) {
    if (u_selectedCount == 0) return false;
    int pid = int(clamp(round(plateIdNorm * float(max(u_plateTotal, 1))), 0.0, float(max(u_plateTotal - 1, 0))));
    float mask = texture(u_selectionMaskTex, vec2((float(pid) + 0.5) / 256.0, 0.5)).r;
    return mask > 0.5;
}
void main() {
    vec2 uv = v_uv;
    float sea = u_seaLevel;
    vec3 col;
    float plateId = 0.0, boundary = 0.0, elev = 0.0, moisture = 0.0;
    if (u_style == 4) {
        float grid = u_resolution.x / 8.0;
        vec2 scaled = uv * grid;
        vec2 ip = floor(scaled);
        vec2 fp = fract(scaled);
        float tri = step(fp.x, fp.y);
        vec2 center = (tri < 0.5) ? (ip + vec2(0.666, 0.333)) / grid : (ip + vec2(0.333, 0.666)) / grid;
        elev = texture(u_elevTex, center).r; moisture = texture(u_moistureTex, center).r;
        vec4 pC = texture(u_plateTex, center); plateId = pC.r; boundary = pC.a;
        float tx = 1.0 / grid;
        float eL = texture(u_elevTex, center - vec2(tx, 0.0)).r;
        float eR = texture(u_elevTex, center + vec2(tx, 0.0)).r;
        float eD = texture(u_elevTex, center - vec2(0.0, tx)).r;
        float eU = texture(u_elevTex, center + vec2(0.0, tx)).r;
        vec3 n = normalize(vec3(eL - eR, eD - eU, 0.15));
        vec3 lightDir = normalize(vec3(cos(u_lightAngle), sin(u_lightAngle), 0.55));
        float shade = clamp(dot(n, lightDir), 0.25, 1.15);
        if (elev < sea) col = mix(vec3(0.25, 0.55, 0.90), vec3(0.08, 0.20, 0.50), sea > 0.001 ? (sea - elev) / sea : 0.0);
        else {
            float h = (elev - sea) / (1.0 - sea);
            if (h < 0.04) col = vec3(0.95, 0.88, 0.60);
            else if (h < 0.22) col = mix(vec3(0.45, 0.80, 0.30), vec3(0.30, 0.65, 0.20), (h - 0.04) / 0.18);
            else if (h < 0.50) col = mix(vec3(0.55, 0.50, 0.28), vec3(0.65, 0.58, 0.42), (h - 0.22) / 0.28);
            else if (h < 0.78) col = mix(vec3(0.75, 0.72, 0.68), vec3(0.88, 0.86, 0.84), (h - 0.50) / 0.28);
            else col = vec3(1.0, 1.0, 1.0);
        }
        if (elev >= sea && elev < sea + 0.45) col = mix(col, vec3(0.30, 0.75, 0.45), moisture * 0.25); col *= shade;
        float edgeDist = min(min(min(fp.x, 1.0 - fp.x), min(fp.y, 1.0 - fp.y)), abs(fp.x - fp.y) / 1.414);
        vec3 edgeCol = elev < sea ? vec3(0.05, 0.12, 0.28) : vec3(0.22, 0.18, 0.15);
        col = mix(edgeCol, col, smoothstep(0.0, 0.06, edgeDist));
    } else {
        vec4 plateData = texture(u_plateTex, uv);
        elev = texture(u_elevTex, uv).r; moisture = texture(u_moistureTex, uv).r;
        float temp = texture(u_tempTex, uv).r;
        float river = texture(u_riverTex, uv).r;
        /* v0.3.6: 细节生成器 - 降雨偏移和群系混合度 */
        moisture = clamp(moisture + u_detailRainfallOffset * 0.01, 0.0, 1.0);
        temp = clamp(temp + (u_detailTempGradient - 1.0) * 0.2, 0.0, 1.0);
        plateId = plateData.r; boundary = plateData.a;
        float shade = hillshade(uv, u_lightAngle);
        if (u_fbmOctaves > 0) {
            float detail = 0.0; vec2 p = uv * 12.0; float amp = 0.5; float freq = 1.0;
            for (int i = 0; i < 8; i++) {
                if (i >= u_fbmOctaves) break;
                detail += amp * vnoise(p * freq); freq *= u_fbmLacunarity; amp *= u_fbmPersistence;
            }
            elev += (detail - 0.5) * 0.08; elev = clamp(elev, 0.0, 1.0);
        }
        if (u_style == 0) col = terrainColor(elev, sea, moisture) * shade;
        else if (u_style == 1) col = platesColor(plateId, elev, sea, shade);
        else if (u_style == 2) col = parchmentColor(elev, sea, boundary, plateData.g);
        else if (u_style == 3) {
            if (elev < sea) col = mix(vec3(.08, .20, .45), vec3(.03, .08, .22), sea > 0.001 ? (sea - elev) / sea : 0.0);
            else {
                float m = clamp(moisture, 0.0, 1.0);
                col = m < 0.5 ? mix(vec3(.65, .58, .35), vec3(.25, .55, .18), m * 2.0) : mix(vec3(.25, .55, .18), vec3(.10, .38, .12), (m - 0.5) * 2.0);
                if (elev > sea + 0.3) col = mix(col, vec3(.92, .92, .95), (elev - sea - 0.3) / 0.2);
            } col *= shade;
        }
        /* v0.3.0: 新增渲染风格 */
        else if (u_style == 5) col = terrainDetailColor(elev, sea, moisture, river, shade);
        else if (u_style == 6) col = biomeColor(temp, moisture, elev, sea, shade);
        else if (u_style == 7) col = contourColor(elev, sea, shade);
        else if (u_style == 8) col = reliefColor(elev, sea, shade);
        /* v0.3.4: Azgaar 风格 */
        else if (u_style == 9) col = azgaarColor(elev, sea, moisture, temp, river, shade, boundary);
    }
    if (u_showBoundaries > 0.5 && u_style != 2 && u_style != 4 && u_style != 9) {
        float bw = u_boundaryWidth * 0.05; float bMask = smoothstep(bw, bw + 0.02, boundary);
        col = mix(col, u_boundaryColor, bMask);
    }
    /* v0.3.1: 图层分离——选中高亮受独立开关控制 */
    if (u_showSelection > 0.5 && isSelected(plateId)) {
        float pulse = sin(u_time * 3.0) * 0.5 + 0.5;
        col = mix(col, vec3(1.0, 0.92, 0.3), 0.35 + pulse * 0.2);
    }
    /* v0.3.1: 图层分离——地形底图可独立关闭 */
    if (u_showTerrain < 0.5) {
        col = vec3(0.08, 0.08, 0.12); // 深色背景
    }
    if (u_pointLightEnabled > 0.5) {
        vec2 delta = uv - u_pointLightPos; delta.x *= u_resolution.x / u_resolution.y;
        float dist = length(delta);
        float falloff = 1.0 / (1.0 + dist * 3.0 + dist * dist * 4.0);
        col += u_pointLightColor * falloff * u_pointLightIntensity * 0.25;
        if (u_glowEnabled > 0.5) {
            float halo = exp(-dist * 4.0) * 0.4; float scatter = exp(-dist * 8.0) * elev * 0.2;
            col += u_pointLightColor * (halo + scatter) * u_pointLightIntensity;
        }
    }
    if (u_laserActive > 0.5) {
        vec2 asp = vec2(u_resolution.x / u_resolution.y, 1.0);
        float dist = distToSegment(uv * asp, u_laserStart * asp, u_laserEnd * asp) * u_resolution.y;
        /* v0.3.4: 优化激光指针——更丰富的发光层+动态脉冲 */
        float pulse = 0.85 + 0.15 * sin(u_time * 5.0);
        float glow = smoothstep(u_laserWidth * 8.0, 0.0, dist) * 0.35 * pulse;
        float mid = smoothstep(u_laserWidth * 3.0, 0.0, dist) * 0.55 * pulse;
        float core = smoothstep(u_laserWidth * 0.5, 0.0, dist);
        vec3 glowCol = vec3(1.0, 0.30, 0.10);
        vec3 midCol = vec3(1.0, 0.18, 0.08);
        vec3 coreCol = vec3(1.0, 0.95, 0.85);
        col = mix(col, glowCol, glow);
        col = mix(col, midCol, mid);
        col = mix(col, coreCol, core);
        /* 激光端点光晕 */
        float dStart = length((uv - u_laserStart) * asp) * u_resolution.y;
        float dEnd = length((uv - u_laserEnd) * asp) * u_resolution.y;
        float endGlow1 = smoothstep(u_laserWidth * 12.0, 0.0, dStart) * 0.3 * pulse;
        float endGlow2 = smoothstep(u_laserWidth * 12.0, 0.0, dEnd) * 0.3 * pulse;
        col += vec3(1.0, 0.35, 0.12) * endGlow1;
        col += vec3(1.0, 0.35, 0.12) * endGlow2;
    }
    /* v0.3.4: 光标渲染——GPU端柔和光圈 */
    if (u_cursorActive > 0.5) {
        vec2 asp = vec2(u_resolution.x / u_resolution.y, 1.0);
        float d = length((uv - u_cursorPos) * asp) * u_resolution.y;
        float ring = abs(d - u_cursorSize);
        float ringGlow = smoothstep(3.0, 0.0, ring) * 0.6;
        float innerGlow = smoothstep(u_cursorSize, u_cursorSize * 0.3, d) * 0.08;
        float outerGlow = smoothstep(u_cursorSize * 3.0, u_cursorSize, d) * 0.12;
        float pulse2 = 0.8 + 0.2 * sin(u_time * 3.5);
        vec3 cursorCol = vec3(1.0, 0.82, 0.35);
        col = mix(col, cursorCol, ringGlow * pulse2);
        col += cursorCol * innerGlow * pulse2;
        col += cursorCol * outerGlow * pulse2;
        /* 十字线 */
        float crossH = smoothstep(1.5, 0.0, abs(uv.y - u_cursorPos.y) * u_resolution.y) *
                       smoothstep(u_cursorSize * 3.0, u_cursorSize * 1.5, d) * 0.3;
        float crossV = smoothstep(1.5, 0.0, abs(uv.x - u_cursorPos.x) * u_resolution.y) *
                       smoothstep(u_cursorSize * 3.0, u_cursorSize * 1.5, d) * 0.3;
        col = mix(col, cursorCol, crossH + crossV);
    }
    if (u_hasTrail > 0.5) { vec4 trail = texture(u_trailTex, v_uv); col = mix(col, trail.rgb, trail.a); }
    fragColor = vec4(pow(col, vec3(0.95)), 1.0);
}
